/**
 * @fileoverview Description of this file.
 */

require('./cloud/smart-home-provider-cloud.js');
